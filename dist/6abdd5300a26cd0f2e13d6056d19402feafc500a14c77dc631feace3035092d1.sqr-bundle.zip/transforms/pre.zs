;; default pre-hook
input