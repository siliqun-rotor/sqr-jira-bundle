;; default post-hook
input